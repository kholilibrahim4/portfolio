import React from 'react'

export default function TextareaField({...spread}) {
  return <textarea {...spread} />
}
