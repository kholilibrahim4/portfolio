import React from 'react'

export default function InputField({...spread}) {
  return <input {...spread}/>
}
